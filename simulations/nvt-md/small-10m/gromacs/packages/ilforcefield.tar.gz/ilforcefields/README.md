# ilforcefields
Library of ionic liquid forcefields and builders for use in molecular simulation

# Installation

Clone this repo, nagivate into it, and `pip install -e .`

Run tests with

`py.test -v`
